<template>
  <router-view />
</template>

<script setup lang="ts">
defineOptions({
  name: 'App'
});
</script>
